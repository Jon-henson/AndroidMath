# Google Play listing text

**App name** (30 characters max)
Number Heroes: Math Practice

**Short description** (80 characters max)
Free math practice for Grades 1 to 5. No ads, no sign-up, works offline.

**Full description** (4,000 characters max)
Number Heroes is free math practice for kids in Grades 1 to 5. Every question is made fresh, so there is always more to practice, and every answer comes with step-by-step help.

WHAT'S INSIDE
• More than 340 skills across Grades 1 to 5: counting, place value, addition and subtraction, multiplication and division, fractions, decimals, money, time, measurement, geometry, data and more
• New questions every time, never the same worksheet twice
• Hints, worked steps and "how it works" examples for every skill
• Read aloud: questions can be spoken with your device's voice
• Daily challenge and a 60-second sprint

MOTIVATION THAT WORKS
• Bronze, silver and gold medals for every skill
• Levels and titles as you practice
• A hero avatar with hair, hats, outfits and more to unlock
• Up to 3 heroes per device, each with their own progress

FOR GROWN-UPS
• A protected Grown-ups page with progress, skills that need practice and a 14-day activity chart
• A progress report you can copy and send to a teacher
• Backup codes to move a hero to another device

SAFE BY DESIGN
• No ads, no in-app purchases, no accounts
• Collects no personal information
• No internet needed; works anywhere

**Category:** Education
**Tags:** math, education, kids
**Contact email:** your contact email
**Privacy policy URL:** the address where you host privacy.html (for example, on your GitHub Pages site)
